@extends('layouts.admin')

@section('content');

    <h1 class="h2">Dashboard</h1>

@endsection

