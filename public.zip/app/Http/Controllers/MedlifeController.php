<?php

namespace App\Http\Controllers;

use App\Medlife;
use Illuminate\Http\Request;

class MedlifeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Medlife  $medlife
     * @return \Illuminate\Http\Response
     */
    public function show(Medlife $medlife)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Medlife  $medlife
     * @return \Illuminate\Http\Response
     */
    public function edit(Medlife $medlife)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Medlife  $medlife
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Medlife $medlife)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Medlife  $medlife
     * @return \Illuminate\Http\Response
     */
    public function destroy(Medlife $medlife)
    {
        //
    }
}
